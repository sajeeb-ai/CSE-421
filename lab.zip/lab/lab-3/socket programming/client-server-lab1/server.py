import socket
import threading


HEADER_SIZE = 64

PORT = 5050
SERVER_IPv4 = socket.gethostbyname(socket.gethostname()) #ipv4 address
SOC_ADDRESS = (SERVER_IPv4, PORT)
FORMAT = "UTF-8"
DISCONNECT_MESSAGE = "!DISCONNECT"

# binding the address -> using socket objects
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(SOC_ADDRESS)

def handle_client(conn, ip_address):
    print("[NEW CONNECTION] {ip_address} connected.")
    connected = True
    while connected:
        msg_len = conn.recv(HEADER_SIZE).decode(FORMAT)
        if msg_len:
            msg_len = int(msg_len)
            msg = conn.recv(msg_len).decode(FORMAT)
            conn.send("Message received".encode(FORMAT))
            if msg.isnumeric() == True:
                msg = int(msg)
                result = calculatesalary(msg)
                conn.send(("Your salary is Tk. "+str(result)).encode(FORMAT))

            else:
                conn.send("Invalid Input!".encode(FORMAT))

            if msg == DISCONNECT_MESSAGE:
                connected = False
            print(f"[{ip_address}] {msg}")
            
    conn.close()

        
def calculatesalary(hours:int):
    if hours<40:
        return hours*200
    else:
        return (8000 + (hours - 40) * 300)

"""
conn : socket object
"""
def start():
    server.listen()
    print(f"[LISTENING] Server is listening on {SERVER_IPv4}")
    while True:
        conn, ip_address = server.accept()
        thread = threading.Thread(target = handle_client, args = (conn, ip_address))
        thread.start()
        print("[ACTIVE CONNECTIONS] {threading.activeCount() - 1}")






print("[STARTING] server is starting...")
start()