import socket

HEADER_SIZE = 64
PORT = 5050
FORMAT = "UTF-8"
DISCONNECT_MESSAGE = "!DISCONNECT"
SERVER_IPv4 = "192.168.0.122"
SOC_ADDRESS = (SERVER_IPv4, PORT)

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(SOC_ADDRESS)


def send(msg):
    message = msg.encode(FORMAT)
    msg_length = len(message)
    send_len = str(msg_length).encode(FORMAT)
    send_len += b" " * (HEADER_SIZE -len(send_len))

    client.send(send_len)
    client.send(message)
    print(client.recv(2048).decode(FORMAT))

send("This is the client's message!")
send(DISCONNECT_MESSAGE)